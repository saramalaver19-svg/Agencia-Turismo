document.addEventListener("DOMContentLoaded", function () {
  const btnMostrar = document.getElementById("btnMostrarClientes");
  const tablaDiv = document.getElementById("tabla-clientes");

  const btnMostrarFormulario = document.getElementById("btnMostrarFormulario");
  const divFormulario = document.getElementById("formularioCliente");
  const form = document.getElementById("formCliente");

  const btnMostrarPuntos = document.getElementById("btnMostrarPuntosVisita");
  const tablaPuntosDiv = document.getElementById("tabla-puntosvisita");

  const btnMostrarFormularioPunto = document.getElementById("btnMostrarFormularioPunto");
  const divFormularioPunto = document.getElementById("formularioPuntoVisita");
  const formPunto = document.getElementById("formPuntoVisita");

 
  // Mostrar clientes
  btnMostrar.addEventListener("click", async () => {
    try {
      const response = await fetch("http://localhost:3000/api/clientes");
      if (!response.ok) throw new Error("Error al obtener los clientes");

      const clientes = await response.json();

      if (clientes.length === 0) {
        tablaDiv.innerHTML = "<p>No hay clientes registrados.</p>";
        return;
      }

      let tablaHTML = `
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>Cédula</th><th>Nombre</th><th>Correo</th>
              <th>Teléfono</th><th>Fecha Nacimiento</th>
              <th>Nombre de Contacto</th><th>Teléfono de Contacto</th>
              <th>Fecha Creación</th><th>Fecha Modificación</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
      `;

      clientes.forEach(c => {
        tablaHTML += `
          <tr>
            <td>${c.cedula}</td>
            <td>${c.nombre}</td>
            <td>${c.correo}</td>
            <td>${c.telefonocontacto || ''}</td>
            <td>${c.fechanacimiento?.substring(0, 10) || ''}</td>
            <td>${c.nombrecontacto || ''}</td>
            <td>${c.telefonocontacto2 || ''}</td>
            <td>${c.fechacreacion?.substring(0, 10) || ''}</td>
            <td>${c.fechamodificacion?.substring(0, 10) || ''}</td>
            <td>
              <button class="btn btn-sm btn-danger btn-eliminar">Eliminar</button>
              <button class="btn btn-sm btn-warning btn-editar">Editar</button>
            </td>
          </tr>
        `;
      });

      tablaHTML += "</tbody></table>";
      tablaDiv.innerHTML = tablaHTML;

      // Delegar eventos eliminar y editar
      tablaDiv.querySelectorAll(".btn-eliminar").forEach(button => {
        button.addEventListener("click", async (e) => {
          const fila = e.target.closest("tr");
          const cedula = fila.querySelector("td").textContent;
          if (confirm(`¿Eliminar cliente con cédula ${cedula}?`)) {
            try {
              const res = await fetch(`http://localhost:3000/api/clientes/${cedula}`, { method: "DELETE" });
              const result = await res.json();
              alert(result.message || result.error);
              btnMostrar.click(); // recargar
            } catch (error) {
              alert("Error al eliminar cliente.");
            }
          }
        });
      });

      tablaDiv.querySelectorAll(".btn-editar").forEach(button => {
        button.addEventListener("click", (e) => {
          const fila = e.target.closest("tr");
          const celdas = fila.querySelectorAll("td");

          divFormulario.style.display = "block";
          divFormulario.scrollIntoView({ behavior: "smooth" });

          document.getElementById("cedula").value = celdas[0].textContent;
          document.getElementById("nombre").value = celdas[1].textContent;
          document.getElementById("correo").value = celdas[2].textContent;
          document.getElementById("telefonocontacto").value = celdas[3].textContent;
          document.getElementById("fechanacimiento").value = celdas[4].textContent;
          document.getElementById("nombrecontacto").value = celdas[5].textContent;
          document.getElementById("telefonocontacto2").value = celdas[6].textContent;
          document.getElementById("fechacreacion").value = celdas[7].textContent;
          document.getElementById("fechamodificacion").value = celdas[8].textContent;

          document.getElementById("cedula").readOnly = true;
          document.getElementById("btnGuardar").textContent = "Actualizar Cliente";
          form.dataset.editando = "true";

          btnMostrarFormulario.textContent = "Cancelar";
        });
      });

    } catch (error) {
      tablaDiv.innerHTML = `<p class="text-danger">${error.message}</p>`;
    }
  });

  // Mostrar formulario cliente
  btnMostrarFormulario.addEventListener("click", () => {
    if (divFormulario.style.display === "block") {
      form.reset();
      form.dataset.editando = "false";
      document.getElementById("cedula").readOnly = false;
      document.getElementById("btnGuardar").textContent = "Guardar Cliente";
      divFormulario.style.display = "none";
      btnMostrarFormulario.textContent = "Añadir Cliente";
    } else {
      divFormulario.style.display = "block";
      btnMostrarFormulario.textContent = "Cancelar";
    }
  });

  // Enviar formulario cliente
  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const editando = e.target.dataset.editando === "true";
    const cedula = document.getElementById("cedula").value;

    const data = {
      cedula,
      nombre: document.getElementById("nombre").value,
      correo: document.getElementById("correo").value,
      telefonocontacto: document.getElementById("telefonocontacto").value,
      fechanacimiento: document.getElementById("fechanacimiento").value,
      nombrecontacto: document.getElementById("nombrecontacto").value,
      telefonocontacto2: document.getElementById("telefonocontacto2").value,
      fechacreacion: document.getElementById("fechacreacion").value,
      fechamodificacion: document.getElementById("fechamodificacion").value,
    };

    const url = `http://localhost:3000/api/clientes${editando ? "/" + cedula : ""}`;
    const method = editando ? "PUT" : "POST";

    try {
      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      const result = await response.json();
      alert(result.message || result.error);
    } catch (error) {
      alert("Error al guardar cliente.");
    }

    // Resetear
    form.reset();
    form.dataset.editando = "false";
    document.getElementById("cedula").readOnly = false;
    document.getElementById("btnGuardar").textContent = "Guardar Cliente";
    divFormulario.style.display = "none";
    btnMostrarFormulario.textContent = "Añadir Cliente";

    btnMostrar.click();
  });

  
});
