const express = require('express');
const router = express.Router();
const pool = require('../db');


router.get('/', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM vendedor');
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al obtener los vendedores' });
  }
});

router.post('/', async (req, res) => {
    const {
        cedula,
        nombre,
        correo,
        telefono_vendedor,
        telefono_vendedor2,
        fechamodificacion,
        fechacreacion,
        fechanacimiento,
        username,
        password,
        rol
    }   = req.body;

    try {
        await pool.query(`
            INSERT INTO vendedor (cedula, nombre, correo, telefono_vendedor, telefono_vendedor2, fechamodificacion, fechacreacion, fechanacimiento, username, password, rol)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
        `, [cedula, nombre, correo, telefono_vendedor, telefono_vendedor2, fechamodificacion, fechacreacion, fechanacimiento, username, password, rol]);

        res.status(201).json({ message: 'registrado correctamente' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error al registrar el vendedor' });
    }
});


router.put('/:cedula', async (req, res) => {
    const { cedula } = req.params;
    const {
        nombre,
        correo,
        telefono_vendedor,
        telefono_vendedor2,
        fechamodificacion,
        fechacreacion,
        fechanacimiento,
        username,
        password,
        rol
    } = req.body;

    try {
        await pool.query(`
            UPDATE vendedor
            SET nombre = $1,
            correo = $2,
            telefono_vendedor = $3,
            telefono_vendedor2 = $4,
            fechamodificacion = $5,
            fechacreacion = $6,
            fechanacimiento = $7,
            username = $8,
            password = $9,
            rol = $10
            WHERE cedula = $11
        `, [nombre, correo, telefono_vendedor, telefono_vendedor2, fechamodificacion, fechacreacion, fechanacimiento, username, password, rol, cedula]);

        res.json({ message: 'actualizado correctamente' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error al actualizar' });
    }
});


router.delete('/:cedula', async (req, res) => {
    const { cedula } = req.params;

    try {
        await pool.query('DELETE FROM vendedor WHERE cedula = $1', [cedula]);

        res.json({ message: 'eliminado correctamente' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error al eliminar' });
    }
});

module.exports = router;
