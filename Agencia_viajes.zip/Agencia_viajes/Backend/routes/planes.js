const express = require('express');
const router = express.Router();
const pool = require('../db');

// Registrar compra
router.post('/comprar', async (req, res) => {
  const {
    cedula_cliente,
    cedula_vendedor,
    id_plan,
    fecha_inicio,
    fecha_fin,
    cantidad_personas,
    costo_paquete,
    costo_alimentacion
  } = req.body;

  if (!cedula_cliente || !cedula_vendedor || !id_plan || !fecha_inicio || !fecha_fin || !cantidad_personas) {
    return res.status(400).json({ error: 'Faltan datos requeridos.' });
  }

  try {
    const total = Number(costo_paquete || 0) + Number(costo_alimentacion || 0);

    // 1. Insertar en compra
    const compraResult = await pool.query(`
      INSERT INTO compra (cedula_cliente, fechacreacion, costopaquete, costoalimentacion, total)
      VALUES ($1, NOW(), $2, $3, $4)
      RETURNING codigo
    `, [cedula_cliente, costo_paquete, costo_alimentacion, total]);

    const codigoCompra = compraResult.rows[0].codigo;

    // 2. Insertar en detalles_compra
    await pool.query(`
      INSERT INTO detalles_compra (id_planes_turisticos, codigo, fechainicio, fechafin, valortotal, cantidadpersonas)
      VALUES ($1, $2, $3, $4, $5, $6)
    `, [id_plan, codigoCompra, fecha_inicio, fecha_fin, total, cantidad_personas]);

    // 3. Insertar en vende
    await pool.query(`
      INSERT INTO vende (id_planes_turisticos, cedula_cliente, cedula_vendedor)
      VALUES ($1, $2, $3)
    `, [id_plan, cedula_cliente, cedula_vendedor]);

    res.status(201).json({ mensaje: 'Compra registrada correctamente.' });
  } catch (error) {
    console.error('Error al registrar la compra:', error);
    res.status(500).json({ error: 'Error al procesar la compra.' });
  }
});

module.exports = router;