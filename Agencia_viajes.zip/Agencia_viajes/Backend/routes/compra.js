const express = require('express');
const router = express.Router();
const pool = require('../db'); // Asegúrate de tener una conexión pool

router.post('/', async (req, res) => {
  const {
    cedula_cliente,
    fechacreacion,
    costopaquete,
    costoalimentacion,
    total,
    id_planes_turisticos,
    cedula_vendedor,
    fechainicio,
    fechafin,
    valortotal,
    cantidadpersonas
  } = req.body;

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Insertar en Compra
    const compraResult = await client.query(
      `INSERT INTO compra (cedula_cliente, fechacreacion, costopaquete, costoalimentacion, total)
       VALUES ($1, $2, $3, $4, $5) RETURNING codigo`,
      [cedula_cliente, fechacreacion, costopaquete, costoalimentacion, total]
    );

    const codigoCompra = compraResult.rows[0].codigo;

    // Insertar en Detalles_Compra
    await client.query(
      `INSERT INTO detalles_compra (id_planes_turisticos, codigo, fechainicio, fechafin, valortotal, cantidadpersonas)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [id_planes_turisticos, codigoCompra, fechainicio, fechafin, valortotal, cantidadpersonas]
    );

    // Insertar en Ventas_Realizadas
    await client.query(
      `INSERT INTO vende (id_planes_turisticos, cedula_cliente, cedula_vendedor, fechaventa)
       VALUES ($1, $2, $3, $4)`,
      [id_planes_turisticos, cedula_cliente, cedula_vendedor, fechacreacion]
    );

    await client.query('COMMIT');
    res.json({ mensaje: 'Compra registrada con éxito' });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error(error);
    res.status(500).json({ error: 'Error al registrar la compra' });
  } finally {
    client.release();
  }
});


router.get('/', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM detalles_compra');
    res.json(result.rows);
  } catch (error) {
    console.error('Error al obtener detalles_compra:', error);
    res.status(500).json({ error: 'Error al obtener detalles de compra' });
  }
});


module.exports = router;
