const express = require('express');
const router = express.Router();
const pool = require('../db');

// Obtener todos los puntos de visita
router.get('/', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM puntos_visita');
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al obtener los puntos de visita' });
  }
});

// Insertar nuevo punto de visita
router.post('/', async (req, res) => {
  const {
    id_punto_visita,
    titulo,
    descripcion,
    estado,
    id_departamento,
    id_ciudad,
    fechacreacion,
    fechamodificacion
  } = req.body;

  try {
    await pool.query(`
      INSERT INTO puntos_visita (id_punto_visita, titulo, descripcion, estado, id_departamento, id_ciudad, fechacreacion, fechamodificacion)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
    `, [id_punto_visita, titulo, descripcion, estado, id_departamento, id_ciudad, fechacreacion, fechamodificacion]);

    res.status(201).json({ message: 'Punto de visita registrado correctamente' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al registrar el punto de visita' });
  }
});


// Actualizar punto de visita
router.put('/:id_punto_visita', async (req, res) => {
  const { id_punto_visita } = req.params;
  const {
    titulo,
    descripcion,
    estado,
    id_departamento,
    id_ciudad,
    fechacreacion,
    fechamodificacion
  } = req.body;

  try {
    await pool.query(`
      UPDATE puntos_visita
      SET titulo = $1,
          descripcion = $2,
          estado = $3,
          id_departamento = $4,
          id_ciudad = $5,
          fechacreacion = $6,
          fechamodificacion = $7
      WHERE id_punto_visita = $8
    `, [titulo, descripcion, estado, id_departamento, id_ciudad, fechacreacion, fechamodificacion, id_punto_visita]);

    res.json({ message: 'Punto de visita actualizado correctamente' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al actualizar el punto de visita' });
  }
});



// Eliminar punto de visita
router.delete('/:id_punto_visita', async (req, res) => {
  const { id_punto_visita } = req.params;

  try {
    await pool.query('DELETE FROM puntos_visita WHERE id_punto_visita = $1', [id_punto_visita]);

    res.json({ message: 'Punto de visita eliminado correctamente' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al eliminar el punto de visita' });
  }
});

module.exports = router; 