const express = require('express');
const router = express.Router();
const pool = require('../db');

// Obtener todos los clientes
router.get('/', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM cliente');
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al obtener los clientes' });
  }
});

// Insertar nuevo cliente
router.post('/', async (req, res) => {
  const {
    cedula,
    nombre,
    correo,
    telefonocontacto,
    fechanacimiento,
    nombrecontacto,
    telefonocontacto2,
    fechacreacion,
    fechamodificacion
  } = req.body;

  try {
    await pool.query(`
      INSERT INTO cliente (cedula, nombre, correo, telefonocontacto, fechanacimiento, nombrecontacto, telefonocontacto2,  fechacreacion, fechamodificacion)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
    `, [cedula, nombre, correo, telefonocontacto, fechanacimiento, nombrecontacto, telefonocontacto2, fechacreacion, fechamodificacion]);

    res.status(201).json({ message: 'Cliente registrado correctamente' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al registrar el cliente' });
  }
});


// Actualizar cliente
router.put('/:cedula', async (req, res) => {
  const { cedula } = req.params;
  const {
    nombre,
    correo,
    telefonocontacto,
    fechanacimiento,
    nombrecontacto,
    telefonocontacto2,
    fechacreacion,
    fechamodificacion
  } = req.body;

  try {
    await pool.query(`
      UPDATE cliente
      SET nombre = $1,
          correo = $2,
          telefonocontacto = $3,
          fechanacimiento = $4,
          nombrecontacto = $5,
          telefonocontacto2 = $6,
          fechacreacion = $7,
          fechamodificacion = $8
      WHERE cedula = $9
    `, [nombre, correo, telefonocontacto, fechanacimiento, nombrecontacto, telefonocontacto2, fechacreacion, fechamodificacion, cedula]);

    res.json({ message: 'Cliente actualizado correctamente' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al actualizar el cliente' });
  }
});



// Eliminar cliente
router.delete('/:cedula', async (req, res) => {
  const { cedula } = req.params;

  try {
    await pool.query('DELETE FROM cliente WHERE cedula = $1', [cedula]);

    res.json({ message: 'Cliente eliminado correctamente' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al eliminar el cliente' });
  }
});

module.exports = router;