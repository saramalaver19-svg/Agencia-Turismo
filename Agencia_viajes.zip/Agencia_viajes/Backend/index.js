const express = require('express');
const cors = require('cors');
const app = express();

const clientesRoutes = require('./routes/clientes');
const authRoutes = require('./routes/auth');
const planesRoutes = require('./routes/planes');
const PuntosVisitaRoutes = require('./routes/PuntosVisita');
const compraRoutes = require('./routes/compra');
const vendedoresRoutes = require('./routes/vendedor');



app.use(cors());
app.use(express.json());

// Montar rutas
app.use('/api/clientes', clientesRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/planes', planesRoutes);
app.use('/api/PuntosVisita', PuntosVisitaRoutes);
app.use('/api/compra', compraRoutes);
app.use('/api/vendedor', vendedoresRoutes);


const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});

