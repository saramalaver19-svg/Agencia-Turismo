const { Pool } = require('pg');

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'BD_Turismo',
  password: 'turismo',
  port: 5432
});

module.exports = pool;
